﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minesweeper {
    public class Cell {
        public bool Mine { get; set; } = false;
        public bool Flag { get; set; } = false;
        public bool Opened { get; set; } = false;
        public int Value { get; set; } = 0;
        public Image Image {
            get {
                if (Flag)
                    return flag;
                if (!Opened)
                    return notOpened;
                if (Mine)
                    return mine;
                return numbers[Value];
            }
        }

        private static Image flag = Resources.Flag;
        private static Image notOpened = Resources.NotOpened;
        private static Image mine = Resources.Mine;
        private static Dictionary<int, Image> numbers = new Dictionary<int, Image>() {
            { 0, Resources.Opened0 },
            { 1, Resources.Opened1 },
            { 2, Resources.Opened2 },
            { 3, Resources.Opened3 },
            { 4, Resources.Opened4 },
            { 5, Resources.Opened5 },
            { 6, Resources.Opened6 },
            { 7, Resources.Opened7 },
            { 8, Resources.Opened8 }
        };
    }
}
