﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minesweeper {
    public class Game {
        public Cell[,] Field { get; } = new Cell[8, 8];
        private Game() {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    Field[i, j] = new Cell();
                }
            }
        }
        public static Game Generate() {
            Game game = new Game();
            Random rand = new Random(DateTime.Now.Millisecond);
            int count = 0;
            while (count < 10) {
                int i = rand.Next(0, 8);
                int j = rand.Next(0, 8);
                if (!game.Field[i, j].Mine) {
                    game.Field[i, j].Mine = true;
                    if(i != 0 && j != 0)
                        game.Field[i - 1, j - 1].Value++;
                    if(i != 0)
                        game.Field[i - 1, j].Value++;
                    if(i != 0 && j != 7)
                        game.Field[i - 1, j + 1].Value++;
                    if(j != 7)
                        game.Field[i, j + 1].Value++;
                    if(i != 7 && j != 7)
                        game.Field[i + 1, j + 1].Value++;
                    if(i != 7)
                        game.Field[i + 1, j].Value++;
                    if (i != 7 && j != 0)
                        game.Field[i + 1, j - 1].Value++;
                    if (j != 0)
                        game.Field[i, j - 1].Value++;
                    count++;
                }
            }
            return game;
        }
        public ClickResult Open(int x, int y) {
            if (Field[y, x].Flag || Field[y, x].Opened)
                return ClickResult.None;
            Field[y, x].Opened = true;
            if(Field[y, x].Mine)
                return ClickResult.Lose;
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (!Field[i, j].Mine && !Field[i, j].Opened)
                        return ClickResult.Progress;
                }
            }
            return ClickResult.Win;
        }
        public void ToggleFlag(int x, int y) {
            if (Field[y, x].Opened)
                return;
            Field[y, x].Flag = !Field[y, x].Flag;
        }
    }
}
