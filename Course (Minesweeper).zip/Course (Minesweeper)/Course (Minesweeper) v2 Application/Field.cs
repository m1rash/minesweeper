﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Minesweeper {
    public class Field : Control {
        public Game Game { 
            set {
                game = value;
                Invalidate();
            }
        }
        public SizeF CellSize { get => cellSize; }

        private Game game;

        private BufferedGraphics bg;
        private Graphics g;
        private SizeF cellSize;
        private Size fieldSize;

        public void SetSize(Size size) {
            fieldSize = size;
            cellSize = new SizeF((float)Width / size.Width, (float)Height / size.Height);
        } //используется для настройки размеров игрового поля и для вычисления размера одной ячейки.
        protected override void OnPaint(PaintEventArgs e) {
            g.Clear(BackColor);
            if(game != null) {
                for(int i = 0; i < fieldSize.Height; i++) {
                    for(int j = 0; j < fieldSize.Width; j++) {
                        g.DrawImage(game.Field[i, j].Image, new RectangleF(j * cellSize.Width, i * cellSize.Height, cellSize.Width, cellSize.Height));
                    }
                }
            }
            bg.Render(e.Graphics);
        } //Этот метод рисует игровое поле на буфере с использованием изображений, размещая изображения в соответствии с размерами ячейки и позицией на поле.
        protected override void OnCreateControl() {
            base.OnCreateControl();
            bg = BufferedGraphicsManager.Current.Allocate(Graphics.FromImage(new Bitmap(Width + 1, Height + 1)), new Rectangle(0, 0, Width + 1, Height + 1));
            g = bg.Graphics; //Этот метод настраивает буферизованную графику, чтобы обеспечить более плавную и эффективную отрисовку игрового поля.
        }
    }
}
