﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Minesweeper {
    public partial class GameForm : Form {
        private Game game;
        public GameForm() {
            InitializeComponent();
            game = Game.Generate();
            field.Game = game;
        }

        private void field_MouseClick(object sender, MouseEventArgs e) {
            int x = e.X / (int)field.CellSize.Width;
            int y = e.Y / (int)field.CellSize.Height;
            if(e.Button == MouseButtons.Left) {
                ClickResult result = game.Open(x, y);
                if (result != ClickResult.None)
                    field.Invalidate();
                if (result == ClickResult.Win) {
                    MessageBox.Show("Победа");
                    Close();
                }
                else if(result == ClickResult.Lose) {
                    MessageBox.Show("Поражение!");
                    Close();
                }
            }
            else if(e.Button == MouseButtons.Right) {
                game.ToggleFlag(x, y);
                field.Invalidate();
            }
        }
    }
}
