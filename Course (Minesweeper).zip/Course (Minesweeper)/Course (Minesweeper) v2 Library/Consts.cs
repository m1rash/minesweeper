﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minesweeper {
    public static class Consts {
        public static readonly Dictionary<Difficulty, Size> FieldSize = new Dictionary<Difficulty, Size>() {
            { Difficulty.Starter, new Size(8, 8) },
            { Difficulty.Medium, new Size(13, 13) },
            { Difficulty.Expert, new Size(18, 18) }
        };

        public static readonly Dictionary<Difficulty, int> Mines = new Dictionary<Difficulty, int>() {
            { Difficulty.Starter, 10 },
            { Difficulty.Medium, 40 }, 
            { Difficulty.Expert, 100 }
        };
    }
}
