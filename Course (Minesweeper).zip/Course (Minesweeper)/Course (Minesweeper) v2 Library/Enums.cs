﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minesweeper {
    public enum ClickResult {
        None,
        Progress,
        Win,
        Lose
    }

    public enum Difficulty {
        Starter,
        Medium,
        Expert
    }
}
