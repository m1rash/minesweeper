﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minesweeper {
    public class Game {
        public Cell[,] Field { get; }
        public bool Template { get; set; } = false;

        private Size size;
        private Game(Size size) {
            Field = new Cell[size.Height, size.Width];

            for (int i = 0; i < size.Height; i++) {
                for (int j = 0; j < size.Width; j++) {
                    Field[i, j] = new Cell();
                }
            }

            this.size = size;
        }
        public static Game Generate(Difficulty difficulty, int x, int y) {
            Size size = Consts.FieldSize[difficulty];
            int mines = Consts.Mines[difficulty];

            Game game = new Game(size);
            Random rand = new Random(DateTime.Now.Millisecond);
            int count = 0;
            while (count < mines) {
                int i = rand.Next(0, size.Height);
                int j = rand.Next(0, size.Width);
                if (i >= y - 1 && i <= y + 1 && j >= x - 1 && j <= x + 1)
                    continue;
                if (!game.Field[i, j].Mine) {
                    game.Field[i, j].Mine = true;
                    if(i != 0 && j != 0)
                        game.Field[i - 1, j - 1].Value++;
                    if(i != 0)
                        game.Field[i - 1, j].Value++;
                    if(i != 0 && j != size.Width - 1)
                        game.Field[i - 1, j + 1].Value++;
                    if(j != size.Width - 1)
                        game.Field[i, j + 1].Value++;
                    if(i != size.Height - 1 && j != size.Width - 1)
                        game.Field[i + 1, j + 1].Value++;
                    if(i != size.Width - 1)
                        game.Field[i + 1, j].Value++;
                    if (i != size.Width - 1 && j != 0)
                        game.Field[i + 1, j - 1].Value++;
                    if (j != 0)
                        game.Field[i, j - 1].Value++;
                    count++;
                }
            }
            return game;
        } //генерирует случайные позиции для мин, избегая размещения мин слишком близко к начальной позиции игрока.
        public static Game GenerateTemplate(Difficulty difficulty) {
            Game game = new Game(Consts.FieldSize[difficulty]);
            game.Template = true;
            return game;
        }
        public ClickResult Open(int x, int y) {
            if (Field[y, x].Flag || Field[y, x].Opened)
                return ClickResult.None;
            OpenInternal(x, y, new List<Point>());
            if (Field[y, x].Mine)
                return ClickResult.Lose;
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (!Field[i, j].Mine && !Field[i, j].Opened)
                        return ClickResult.Progress;
                }
            }
            return ClickResult.Win;
        } // обрабатывает клик по ячейке игрового поля. Он проверяет, не открыта ли ячейка уже, не помечена ли она флагом и не содержит ли она мину.
        public void ToggleFlag(int x, int y) {
            if (Field[y, x].Opened)
                return;
            Field[y, x].Flag = !Field[y, x].Flag;
        }
        private void OpenInternal(int x, int y, List<Point> visitedCells) {
            Field[y, x].Opened = true;
            visitedCells.Add(new Point(x, y));
            if(Field[y, x].Value == 0) {
                if (x != 0 && y != 0 && !visitedCells.Contains(new Point(x - 1, y - 1)))
                    OpenInternal(x - 1, y - 1, visitedCells);
                if (x != 0 && !visitedCells.Contains(new Point(x - 1, y)))
                    OpenInternal(x - 1, y, visitedCells);
                if (x != 0 && y != size.Width - 1 && !visitedCells.Contains(new Point(x - 1, y + 1)))
                    OpenInternal(x - 1, y + 1, visitedCells);
                if (y != size.Width - 1 && !visitedCells.Contains(new Point(x, y + 1)))
                    OpenInternal(x, y + 1, visitedCells);
                if (x != size.Height - 1 && y != size.Width - 1 && !visitedCells.Contains(new Point(x + 1, y + 1)))
                    OpenInternal(x + 1, y + 1, visitedCells);
                if (x != size.Width - 1 && !visitedCells.Contains(new Point(x + 1, y)))
                    OpenInternal(x + 1, y, visitedCells);
                if (x != size.Width - 1 && y != 0 && !visitedCells.Contains(new Point(x + 1, y - 1)))
                    OpenInternal(x + 1, y - 1, visitedCells);
                if (y != 0 && !visitedCells.Contains(new Point(x, y - 1)))
                    OpenInternal(x, y - 1, visitedCells);
            }
        } // используется для открытия пустых ячеек и их соседей на игровом поле.
    }
}
